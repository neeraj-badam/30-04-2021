const { urlencoded, response } = require("express")
var express = require("express")

var path = require("path")

var app = new express()
app.use(express.static("public"))
app.use(express.urlencoded())

app.get("/",(req,response)=>{
    response.sendFile(path.join(__dirname,"index.html"))
})

app.get("/getUser/:id",(req,response)=>{
    id = req.params.id
    response.send(id);
})

app.post("/signup",(req,response)=>{
    response.send(req.body.username)
})

app.delete("/deleteUser",(req,response)=>{
    response.send("Delete method")
})

app.get("/getUser",(req,response)=>{
    response.send("Get method")
})

app.listen(8000,()=>{
    console.log("server started")
})